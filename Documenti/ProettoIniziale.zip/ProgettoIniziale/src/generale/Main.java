package generale;
import javax.swing.JFrame;

import frame.GiocoFrame;

public class Main {

	public static void main(String[] args) {
		
		GiocoFrame start = new GiocoFrame();
		start.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		start.setLocationRelativeTo(null);
		start.setVisible(true);
		
	}

}
 