package interfacce;

public interface Energetico {
	int getEnergia();
	int getX();
	int getY();
}
